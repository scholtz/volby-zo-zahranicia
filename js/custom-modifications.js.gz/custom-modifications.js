$(document).ready(function ()
{
$("#logo").attr("title","Voľby do NR SR 2020 - Online žiadosť o voľbu poštou zo zahraničia a hlasovací preukaz - Srdcom doma.");
$(".navbar-brand").attr("href","https://volby.srdcomdoma.sk");
$(".supported-by").hide();
});